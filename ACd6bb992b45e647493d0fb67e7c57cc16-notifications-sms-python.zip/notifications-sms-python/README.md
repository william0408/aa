# SMS Notification PUB/SUB Example

## Goal

You've got a twilio app ready to run! Let this application serve as a guide to understand building a Twilio Application.

## Usage

1. run `make install number=<phone number>` with a Phone Number you [bought in the Twilio Console](https://www.twilio.com/console/phone-numbers)` to setup the application
1. run `make serve` to start the application
1. With your app running, send a text message of "Hello" to the Twilio phone number. Follow it's instructions to subscribe to notifications.
1. Get some friends to text it too!
1. Use the [locally running web interface](http://localhost:8080) to send notifications to all who have subscribed
1. Explore the code to learn how it all works together!
1. run `make serve number=<phone number>` at any point to configure a different Twilio phone number!

## Requirements

- Python 3
- Mac OS X or Linux

## Technical Notes

The app will install & run `ngrok` in the background. This will open your local 8080 port to the internet.

## Troubleshooting Tips
If your server is running, and you text the right phone number while not hearing back, you may want to check the [debugger](https://www.twilio.com/console/runtime/debugger) at upper right corner in your twilio dashboard to see the error message. For example:
- Payment Required
  - your account has insufficient balance
- Request reached timeout
  - simply try again
- In response body it says "Tunnel Expired"
  - possibly you ran a ngrok instance a long time ago and didn't terminate it correctly
  - go to terminal and check ngrok process `ps -A | grep ngrok`
  - kill all active ngrok processess `kill <pid>`