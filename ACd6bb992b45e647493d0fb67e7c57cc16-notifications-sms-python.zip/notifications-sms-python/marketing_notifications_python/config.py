import json
import os

class DefaultConfig(object):
    SECRET_KEY = '%^!@@*!&$8xyzefb52438#(&^874@#^&*($@*(@&^@)(&*)Y_)((+'
    DEBUG = True
    TWILIO_ACCOUNT_SID = 'xx'
    TWILIO_AUTH_TOKEN = 'xx'
    TWILIO_NUMBER = '+xx'
    CONFIG_PATH = os.path.abspath('./config.json')

    def write_to_config(self, data):
        with open(self.CONFIG_PATH, 'w') as config_file:
            json.dump(data, config_file, indent=1)

    def read_from_config(self):
        with open(self.CONFIG_PATH, 'r') as config_file:
            return json.load(config_file)

class DevelopmentConfig(DefaultConfig):
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///dev.sqlite'


class TestConfig(DefaultConfig):
    SQLALCHEMY_DATABASE_URI = 'sqlite:///test.sqlite'
    PRESERVE_CONTEXT_ON_EXCEPTION = False
    DEBUG = True
    TESTING = True
    WTF_CSRF_ENABLED = False


config_env_files = {
    'test': 'marketing_notifications_python.config.TestConfig',
    'development': 'marketing_notifications_python.config.DevelopmentConfig',
}
