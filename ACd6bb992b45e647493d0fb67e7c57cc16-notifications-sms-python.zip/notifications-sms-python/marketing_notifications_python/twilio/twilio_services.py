from twilio.http.http_client import TwilioHttpClient

from marketing_notifications_python.config import DefaultConfig
from marketing_notifications_python.twilio import account_sid, auth_token, phone_number
from twilio.twiml.messaging_response import MessagingResponse
from twilio.rest import Client
from twilio.base.exceptions import TwilioRestException
from marketing_notifications_python.NgrokRunner import NgrokRunner
from requests.exceptions import HTTPError


class HttpClient(TwilioHttpClient):

    def request(self, method, url, params=None, data=None, headers=None,
                auth=None, timeout=None, allow_redirects=False):
        headers = headers or {}
        headers['User-Agent'] = '{} {}'.format(headers.get('User-Agent', ''), 'kickstart/twilio/marketing-notifications')
        return super().request(
            method,
            url,
            params=params,
            data=data,
            headers=headers,
            auth=auth,
            timeout=timeout,
            allow_redirects=allow_redirects
        )


class TwilioServices(object):

    def __init__(self):
        self.twilio_client = Client(account_sid(), auth_token(), http_client=HttpClient())

    def send_message(self, to, message, image_url):
        self.twilio_client.messages.create(
            to=to,
            from_=phone_number(),
            body=message,
            media_url=image_url
        )

    def respond_message(self, message):
        response = MessagingResponse()
        response.message(message)
        return response

    def configure_phone_number(self, number):
        proxy_uri = NgrokRunner.get_proxy_uri()

        print("your public ngrok URL: {}".format(proxy_uri))

        numbers_list = self.twilio_client.incoming_phone_numbers.list(phone_number=number)

        if not len(numbers_list):
            raise Exception("There was an error with your Twilio phone number. Please double check the number and try again")

        number_to_update = numbers_list[0]

        data = DefaultConfig().read_from_config()
        data['TWILIO_NUMBER'] = number_to_update.phone_number
        DefaultConfig().write_to_config(data)

        number_to_update.update(sms_url="{}/message".format(proxy_uri))
