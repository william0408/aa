from flask.ext.sqlalchemy import SQLAlchemy

from flask import Flask
from marketing_notifications_python import get_env, get_phone_number
from marketing_notifications_python.config import config_env_files
from marketing_notifications_python.database import set_db
from marketing_notifications_python.views import construct_view_blueprint
from marketing_notifications_python.config import DefaultConfig
import os

apps = {
    'test': None,
    'development': None,
    'install': None
}


def get_app(config_name=None):
    if config_name is None:
        config_name = get_env()

    if apps[config_name] is None:
        apps[config_name] = init_app(config_name)

    return apps[config_name]


def init_app(config_name):
    flask_app = Flask(__name__)
    _configure_app(flask_app, config_name)
    return flask_app


def _configure_app(flask_app, config_name):
    if config_name == 'test':
        flask_app.config.from_object(config_env_files[config_name])
    else:
        db_path = os.path.abspath('./marketing.sqlite')

        default_config = DefaultConfig()
        config = default_config.read_from_config()
        config['TWILIO_NUMBER'] = get_phone_number() or config['TWILIO_NUMBER']
        default_config.write_to_config(config)

        flask_app.config['TWILIO_ACCOUNT_SID'] = config['TWILIO_ACCOUNT_SID']
        flask_app.config['TWILIO_AUTH_TOKEN'] = config['TWILIO_AUTH_TOKEN']
        flask_app.config['TWILIO_NUMBER'] = config['TWILIO_NUMBER']
        flask_app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_path
    # common to both
    flask_app.config['DEBUG'] = True
    flask_app.config['SECRET_KEY'] = '%^!@@*!&$8xyzefb52438#(&^874@#^&*($@*(@&^@)(&*)Y_)((+'
    flask_app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    app_db = SQLAlchemy(flask_app)
    set_db(app_db, config_name)
    flask_app.register_blueprint(construct_view_blueprint(flask_app, app_db))
