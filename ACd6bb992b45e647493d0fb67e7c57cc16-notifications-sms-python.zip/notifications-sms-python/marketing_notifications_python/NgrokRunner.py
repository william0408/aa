from marketing_notifications_python.config import DefaultConfig
import subprocess
import requests
import json
import time
import webbrowser
import os

class NgrokRunner(object):

    process = None
    defaultConfig = DefaultConfig()

    def start(self, port):
        if self.process:
            print("ngrok already running, PID: {}".format(self.process.pid))
            return
        port = str(port)
        self.process = subprocess.Popen(
            ['./ngrok', 'http', port],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        debug = "ngrok in background, proxying port {}, PID is {}"
        print(debug.format(port, self.process.pid))
        self.open_in_browser(port)
        time.sleep(.5)

    def open_in_browser(self, port):
        data = self.defaultConfig.read_from_config()

        # WERKZEUG_RUN_MAIN is environment variable from flask which is a flag stating the server rebooted
        # Check if server is running the first time, aka has not rebooted, then reset HAS_BROWSER_OPENED flag to false
        if os.environ.get('WERKZEUG_RUN_MAIN') != 'true':
            data["HAS_BROWSER_OPENED"] = "false"
            self.defaultConfig.write_to_config(data)

        # Check if server is rebooted, aka running the second time, and browser hasn't opened yet
        if data["HAS_BROWSER_OPENED"] != "true" and os.environ.get('WERKZEUG_RUN_MAIN') == 'true':
            webbrowser.open('http://localhost:' + port)
            data["HAS_BROWSER_OPENED"] = "true"
            self.defaultConfig.write_to_config(data)

    def stop(self):
        if self.process:
            print("ngrok exiting, PID was {}".format(self.process.pid))
            self.process.terminate()
            try:
                self.process.wait(timeout=1.0)
                print("ngrok shutdown successfully")
            except subprocess.TimeoutExpired:
                print("ngrok took longer than expected to end")

    @staticmethod
    def get_proxy_uri():
        RETRIES_LIMIT = 5
        tunnel = None
        retries = 0

        while tunnel is None:
            if retries >= 5:
                raise Exception("We were unable to successfully start ngrok after {} retries. Please try restarting the service again".format(RETRIES_LIMIT))
            try:
                response = requests.get("http://0.0.0.0:4040/api/tunnels")

                if response.ok:
                    tunnels = json.loads(response.content)

                    if len(tunnels['tunnels']):
                        tunnel = tunnels['tunnels'][0]['public_url']
            # There is an non-deterministic issue with the initial request to ngrok that
            # can throw connection exceptions which should still be retried
            except:
                pass

            retries += 1
            time.sleep(.5)

        return tunnel
