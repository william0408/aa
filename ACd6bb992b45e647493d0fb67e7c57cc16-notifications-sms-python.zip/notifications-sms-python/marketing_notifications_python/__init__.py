import os


def get_env():
    return os.getenv('ENV', 'development')

def get_phone_number():
    return os.getenv('PHONE_NUMBER', None)
