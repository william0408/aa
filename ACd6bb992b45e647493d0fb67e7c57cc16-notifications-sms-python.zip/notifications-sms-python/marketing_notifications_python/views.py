from flask import request, flash, Blueprint
import phonenumbers
from phonenumbers.phonenumberutil import region_code_for_number

from marketing_notifications_python.config import DefaultConfig
from marketing_notifications_python.forms import SendMessageForm
from marketing_notifications_python.models import init_models_module
from marketing_notifications_python.twilio import init_twilio_module, phone_number
from marketing_notifications_python.view_helpers import twiml, view
from marketing_notifications_python.twilio.twilio_services import TwilioServices
from marketing_notifications_python import get_env


def construct_view_blueprint(app, db):
    SUBSCRIBE_COMMAND = "subscribe"
    UNSUBSCRIBE_COMMAND = "unsubscribe"

    views = Blueprint("views", __name__)

    init_twilio_module(app)
    init_models_module(db)
    from marketing_notifications_python.models.subscriber import Subscriber
    twilio_services = TwilioServices()

    if get_env() == 'development':
        twilio_services.configure_phone_number(app.config['TWILIO_NUMBER'])

    @views.route('/', methods=["GET", "POST"])
    @views.route('/notifications', methods=["GET", "POST"])
    def notifications():
        form = SendMessageForm()
        config = DefaultConfig().read_from_config()
        application_region_code = region_code_for_number(phonenumbers.parse(config['TWILIO_NUMBER']))
        international_numbers = []

        if request.method == 'POST' and form.validate_on_submit():
            subscribers = Subscriber.query.filter(Subscriber.subscribed).all()
            if len(subscribers) > 0:
                flash('Messages on their way!')
                for s in subscribers:
                    requester_region_code = region_code_for_number(phonenumbers.parse(s.phone_number))
                    if requester_region_code != application_region_code:
                        international_numbers.append(s.phone_number)
                    else:
                        twilio_services.send_message(s.phone_number, form.message.data, form.imageUrl.data)
            else:
                flash('No subscribers found!')

            if len(international_numbers) > 0:
                flash("Messages could not be sent to [{}] since its region code is not {}.".format(
                    ", ".join(international_numbers),
                    application_region_code
                ))

            form.reset()
            return view('notifications', form)

        return view('notifications', form)

    @views.route('/message', methods=["POST"])
    def message():
        subscriber = Subscriber.query.filter(Subscriber.phone_number == request.form['From']).first()
        if subscriber is None:
            subscriber = Subscriber(phone_number=request.form['From'])
            db.session.add(subscriber)
            db.session.commit()
            output = "Thanks for contacting TWBC! Text 'subscribe' if you would like to receive updates via text message."
        else:
            output = _process_message(request.form['Body'], subscriber)
            db.session.commit()

        return twiml(twilio_services.respond_message(output))

    def _process_message(message, subscriber):
        output = "Sorry, we don't recognize that command. Available commands are: 'subscribe' or 'unsubscribe'."
        message = message.lower()
        if message.startswith(SUBSCRIBE_COMMAND) or message.startswith(UNSUBSCRIBE_COMMAND):
            subscriber.subscribed = message.startswith(SUBSCRIBE_COMMAND)

            if subscriber.subscribed:
                output = "You are now subscribed for updates."
            else:
                output = "You have unsubscribed from notifications. Text 'subscribe' to start receiving updates again"

        return output

    return views
