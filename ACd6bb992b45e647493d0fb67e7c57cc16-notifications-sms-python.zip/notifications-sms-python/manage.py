from flask.ext.script import Manager, Server
from flask.ext.migrate import Migrate, MigrateCommand
from marketing_notifications_python.bootstrap import get_app
from marketing_notifications_python.database import get_db
from marketing_notifications_python.NgrokRunner import NgrokRunner
from marketing_notifications_python import get_env
import sys

APP_PORT = 7777
ENV_INSTALL = 'install'
APP_HOST = "0.0.0.0"

if get_env() != ENV_INSTALL:
    ngrok = NgrokRunner()
    ngrok.start(APP_PORT)

def main():
    try:
        app = get_app()
        db = get_db()

        migrate = Migrate(app, db)

        manager = Manager(app)
        manager.add_command("db", MigrateCommand)

        if get_env() != ENV_INSTALL:
            manager.add_command("runserver", Server(host=APP_HOST, port=APP_PORT))

        manager.run()
    except Exception as e:
        raise e
    finally:
        shutdown()

def shutdown():
    if get_env() != ENV_INSTALL:
        ngrok.stop()


if __name__ == "__main__":
    main()
