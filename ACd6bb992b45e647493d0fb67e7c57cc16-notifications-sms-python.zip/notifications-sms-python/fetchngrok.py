import platform
import subprocess
import urllib.request
import os


URL = "https://chestnut-goose-4756.twil.io/assets/ngrok-stable-darwin-amd64.zip"

msg_unsupported = """
*** Error: Unsupported system: {} ***
Sorry, at this time we only support OS X
Please see the online walkthrough of the code
to learn about SMS/MMS Marketing Notifications

https://www.twilio.com/docs/sms/tutorials/marketing-notifications-python-flask
"""

msg_failed = """
*** Error: Failed to download ngrok ***
Please check your network and try again.
Or provide a `ngrok` executable in this folder.
"""

def main():
    if platform.system() == "Darwin":
        attempt_download(URL, 3)
    else:
        print(msg_unsupported.format(platform.system()))
        exit(1)

def attempt_download(url, attempts):
    if attempts <= 0:
        print(msg_failed)
        exit(2)
    try:
        download(url)
    except:
        print("Failed to download ngrok")
        attempt_download(url, attempts - 1)

def download(url):
    print("Downloading ngrok . . . " + url)
    with open("./ngrok.zip", "wb") as write_handle:
        with urllib.request.urlopen(url) as response:
            write_handle.write(response.read())
    print("downloaded to ngrok.zip")
    print("Unzipping . . .")
    subprocess.run(["unzip", "ngrok.zip"])
    print("removing old zip file")
    subprocess.run(["rm", "ngrok.zip"])


if __name__ == "__main__":
    main()
